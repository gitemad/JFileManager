package Controller;


public interface Command {
	
	public void execute();
}
